#!/usr/bin/env python3
###############################################################################
# Athena Xai v1 — Kokoro-82M ONNX TTS Server (GPU)
#
# Serves text-to-speech via HTTP on port 8002.
# Uses Kokoro-82M with onnxruntime CUDAExecutionProvider (GPU forced).
#
# Endpoints:
#   GET  /health              → {"status": "ok", "engine": "kokoro-gpu", ...}
#   POST /synthesize          → WAV audio (JSON body: text, voice, speed)
#   GET  /voices              → list of available voices
#
# Working example adapted from:
#   https://github.com/thewh1teagle/kokoro-onnx/issues/125
#   (CUDAExecutionProvider with cudnn_conv_algo_search DEFAULT)
###############################################################################
import argparse
import io
import json
import logging
import sys
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

import numpy as np
import soundfile as sf

# ---- Globals set during init ----
kokoro_instance = None
engine_info = {}

# All known Kokoro v1.0 voices
VOICE_LIST = [
    "af_heart",    # American Female — Heart (bella+sarah blend, default)
    "af_sarah",    # American Female — Sarah
    "af_bella",    # American Female — Bella
    "af_nicole",   # American Female — Nicole
    "af_sky",      # American Female — Sky
    "am_adam",     # American Male   — Adam
    "am_michael",  # American Male   — Michael
    "bf_emma",     # British Female  — Emma
    "bf_isabella", # British Female  — Isabella
    "bm_george",   # British Male    — George
    "bm_lewis",    # British Male    — Lewis
]

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    stream=sys.stdout,
)
log = logging.getLogger("athena-tts")


def init_kokoro(model_dir):
    """Initialize Kokoro with GPU ONLY. No CPU fallback — crashes if CUDA unavailable."""
    global kokoro_instance, engine_info
    import onnxruntime as ort
    from kokoro_onnx import Kokoro

    model_path = f"{model_dir}/kokoro-v1.0.onnx"
    voices_path = f"{model_dir}/voices-v1.0.bin"

    # Show available ONNX providers
    available = ort.get_available_providers()
    log.info(f"ONNX Runtime available providers: {available}")

    # HARD FAIL: CUDAExecutionProvider must be available. No CPU fallback.
    if "CUDAExecutionProvider" not in available:
        log.error("FATAL: CUDAExecutionProvider NOT available in onnxruntime!")
        log.error(f"Available providers: {available}")
        log.error("TTS requires GPU. Check CUDA lib mounts and LD_LIBRARY_PATH.")
        raise RuntimeError("CUDAExecutionProvider not available — TTS requires GPU, no CPU fallback")

    # GPU ONLY — no CPUExecutionProvider in the list
    # EXHAUSTIVE search tries every cuDNN algorithm at startup to find ones that
    # keep Conv ops on the optimized GPU path instead of CUDA fallback kernels.
    # Slower first-run startup, but eliminates "OP Conv running in Fallback mode" warnings.
    providers = [
        ("CUDAExecutionProvider", {
            "cudnn_conv_algo_search": "EXHAUSTIVE",
            "do_copy_in_default_stream": "1",
        }),
    ]
    log.info("Kokoro will run on GPU via CUDAExecutionProvider (EXHAUSTIVE conv search, CPU fallback DISABLED)")

    # Create session with CUDA only
    log.info(f"Loading model: {model_path}")
    log.info(f"Loading voices: {voices_path}")
    sess = ort.InferenceSession(model_path, providers=providers)

    # VERIFY GPU is actually active (not silently fallen back)
    actual_providers = sess.get_providers()
    log.info(f"Session active providers: {actual_providers}")
    if "CUDAExecutionProvider" not in actual_providers:
        log.error(f"FATAL: Session started but CUDA not active! Got: {actual_providers}")
        raise RuntimeError(f"CUDA session verification failed — active providers: {actual_providers}")

    log.info("GPU VERIFIED: CUDAExecutionProvider is active")
    kokoro_instance = Kokoro.from_session(sess, voices_path)

    # List available voices
    if hasattr(kokoro_instance, "voices") and kokoro_instance.voices:
        voice_names = list(kokoro_instance.voices.keys())
        log.info(f"Available voices ({len(voice_names)}): {voice_names}")
    else:
        voice_names = VOICE_LIST
        log.info(f"Using hardcoded voice list ({len(voice_names)} voices)")

    engine_info = {
        "engine": "kokoro-82m-onnx",
        "device": "GPU (CUDA — CPU fallback DISABLED)",
        "providers": actual_providers,
        "model": model_path,
        "voices": voice_names,
    }
    log.info("Kokoro TTS ready on GPU (CPU fallback DISABLED)")


class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    """Handle each request in a new thread so health checks don't queue behind synthesis."""
    daemon_threads = True


class TTSHandler(BaseHTTPRequestHandler):
    """HTTP handler for TTS requests."""

    def do_GET(self):
        if self.path == "/health":
            body = json.dumps({"status": "ok", **engine_info}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", len(body))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/voices":
            voices = engine_info.get("voices", VOICE_LIST)
            body = json.dumps({"voices": voices}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", len(body))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_error(404)

    def do_POST(self):
        if self.path == "/synthesize":
            content_len = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(content_len)
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                self.send_error(400, "Invalid JSON")
                return

            text = data.get("text", "")
            voice = data.get("voice", "af_sky")
            speed = float(data.get("speed", 1.0))
            # v60: lang is now a per-request parameter so Path B can render
            # foreign output through the right phonemizer (es/fr/it/ja/zh/etc.)
            # instead of always going through the en-us pipeline.
            lang = data.get("lang", "en-us") or "en-us"

            if not text:
                self.send_error(400, "Missing 'text' field")
                return

            log.info(f"Synthesize: voice={voice} speed={speed} lang={lang} len={len(text)} chars")
            t0 = time.time()

            try:
                samples, sample_rate = kokoro_instance.create(
                    text, voice=voice, speed=speed, lang=lang
                )
            except Exception as e:
                log.error(f"Kokoro error: {e}")
                self.send_error(500, f"TTS error: {e}")
                return

            elapsed = time.time() - t0
            duration = len(samples) / sample_rate
            log.info(f"Generated {duration:.2f}s audio in {elapsed:.3f}s (RTF={elapsed/duration:.2f})")

            # Encode as WAV in memory
            buf = io.BytesIO()
            sf.write(buf, samples, sample_rate, format="WAV")
            wav_bytes = buf.getvalue()

            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", len(wav_bytes))
            self.end_headers()
            self.wfile.write(wav_bytes)
        else:
            self.send_error(404)

    def log_message(self, format, *args):
        """Route HTTP logs through our logger."""
        log.info(f"HTTP {args[0]}")


def main():
    parser = argparse.ArgumentParser(description="Athena Kokoro TTS Server")
    parser.add_argument("--port", type=int, default=8002)
    parser.add_argument("--model-dir", default="/models/tts")
    parser.add_argument("--log-file", default=None)
    args = parser.parse_args()

    if args.log_file:
        fh = logging.FileHandler(args.log_file)
        fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        log.addHandler(fh)

    log.info(f"Starting Athena TTS server on port {args.port}")
    log.info(f"Model directory: {args.model_dir}")

    init_kokoro(args.model_dir)

    server = ThreadingHTTPServer(("0.0.0.0", args.port), TTSHandler)
    log.info(f"TTS server ready on http://0.0.0.0:{args.port}")
    log.info(f"  POST /synthesize  — generate speech")
    log.info(f"  GET  /voices      — list voices")
    log.info(f"  GET  /health      — status check")
    server.serve_forever()


if __name__ == "__main__":
    main()
