#!/bin/bash
###############################################################################
# Athena — audio_gateway.sh   (v58)
# Continuous USB audio device monitor. Runs alongside the pipeline.
#
# v55 changes:
#   #5: handle BOTH USB cards (Composite Device + UACDemoV1.0) independently,
#       not just whichever one pactl listed first.
#   #6: stop hijacking host PulseAudio defaults. The orchestrator addresses
#       sinks by name via paplay --device=, so default sinks no longer need
#       to point at Athena's hardware. Drop set_defaults entirely; only
#       configure_stereo (one-time profile setting) remains.
#
# - Finds USB Composite Device + UACDemoV1.0 via PulseAudio
# - Forces stereo output profile on each
# - Monitors every 3 seconds: if a device disconnects, logs it and keeps
#   checking. When it reconnects, reconfigures stereo.
#
# Runs inside orchestrator container. Talks to host PulseAudio via
# mounted socket at /run/user/1000/pulse/native
###############################################################################

LOG_FILE="${ATHENA_LOG_DIR:-/logs}/audio_gateway.log"

HEADSET_PATTERN="${ATHENA_HEADSET_PATTERN:-Composite Device}"
EXTERNAL_PATTERN="${ATHENA_EXTERNAL_PATTERN:-UACDemoV1}"

log() {
    local msg="[$(date '+%Y-%m-%d %H:%M:%S')] $1"
    echo "$msg" >> "$LOG_FILE"
    echo "  [audio-gw] $1"
}

check_pulse() {
    pactl info >/dev/null 2>&1
    return $?
}

find_card_by_pattern() {
    local pattern="$1"
    pactl list cards short 2>/dev/null | grep -i "$pattern" | awk '{print $2}' | head -1
}

configure_stereo() {
    local card="$1"
    local label="$2"
    if [ -z "$card" ]; then return 1; fi

    for profile in \
        "output:analog-stereo+input:mono-fallback" \
        "output:analog-stereo+input:analog-mono" \
        "output:analog-stereo" \
        "analog-stereo" \
        "output:analog-stereo+input:analog-stereo"; do
        if pactl set-card-profile "$card" "$profile" 2>/dev/null; then
            log "  $label ($card): profile=$profile"
            return 0
        fi
    done

    local auto_profile
    auto_profile=$(pactl list cards 2>/dev/null | \
        awk "/$card/,/^Card/" | \
        grep -oP '^\s+\K\S+' | \
        grep -i "stereo" | head -1)
    if [ -n "$auto_profile" ] && pactl set-card-profile "$card" "$auto_profile" 2>/dev/null; then
        log "  $label ($card): profile=$auto_profile (auto)"
        return 0
    fi

    log "  $label ($card): could not set stereo profile — leaving as-is"
    return 1
}

# ══════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════

echo "" > "$LOG_FILE"
log "Audio Gateway v58 starting"
log "Patterns: headset='$HEADSET_PATTERN' external='$EXTERNAL_PATTERN'"

if ! check_pulse; then
    log "ERROR: PulseAudio not reachable. Check PULSE_SERVER and socket mount."
    log "Pipeline will start but audio may not work until PA is reachable."
    log "Entering monitor loop in case PulseAudio comes up later..."
fi

HEADSET_CARD=$(find_card_by_pattern "$HEADSET_PATTERN")
EXTERNAL_CARD=$(find_card_by_pattern "$EXTERNAL_PATTERN")
HEADSET_CONNECTED=false
EXTERNAL_CONNECTED=false

if [ -n "$HEADSET_CARD" ]; then
    configure_stereo "$HEADSET_CARD" "headset"
    HEADSET_CONNECTED=true
else
    log "Headset card not present (pattern='$HEADSET_PATTERN')"
fi

if [ -n "$EXTERNAL_CARD" ]; then
    configure_stereo "$EXTERNAL_CARD" "external"
    EXTERNAL_CONNECTED=true
else
    log "External speaker card not present (pattern='$EXTERNAL_PATTERN')"
fi

log "Entering monitor loop (checking every 3s)"

# v55: do NOT call set-default-sink/source. The orchestrator addresses sinks
# by name via paplay --device=, so default sinks belong to the user.
while true; do
    sleep 3
    if ! check_pulse; then
        continue
    fi

    CUR_HEADSET=$(find_card_by_pattern "$HEADSET_PATTERN")
    CUR_EXTERNAL=$(find_card_by_pattern "$EXTERNAL_PATTERN")

    if [ -n "$CUR_HEADSET" ] && [ "$HEADSET_CONNECTED" = false ]; then
        log "Headset reconnected: $CUR_HEADSET"
        configure_stereo "$CUR_HEADSET" "headset"
        HEADSET_CARD="$CUR_HEADSET"
        HEADSET_CONNECTED=true
    elif [ -z "$CUR_HEADSET" ] && [ "$HEADSET_CONNECTED" = true ]; then
        log "Headset disconnected"
        HEADSET_CONNECTED=false
    fi

    if [ -n "$CUR_EXTERNAL" ] && [ "$EXTERNAL_CONNECTED" = false ]; then
        log "External speaker reconnected: $CUR_EXTERNAL"
        configure_stereo "$CUR_EXTERNAL" "external"
        EXTERNAL_CARD="$CUR_EXTERNAL"
        EXTERNAL_CONNECTED=true
    elif [ -z "$CUR_EXTERNAL" ] && [ "$EXTERNAL_CONNECTED" = true ]; then
        log "External speaker disconnected"
        EXTERNAL_CONNECTED=false
    fi
done
